/**
 * RunningHub AI App Plugin - Node Definitions
 * 
 * This file defines the custom nodes provided by this plugin.
 * It will be loaded automatically when the plugin is enabled.
 */

(function () {
    'use strict';

    // Hardcoded Webapp ID for this specific RunningHub workflow
    const WEBAPP_ID = '1973555366057390081';
    const PLUGIN_ID = 'sample-runninghub';

    /**
     * Get the RunningHub API key from settings
     * Checks both the main RunningHub key and plugin-specific key
     */
    function getRunningHubApiKey() {
        // First check plugin-specific key
        const pluginKey = PluginManager.getAiKey(`plugin_${PLUGIN_ID}`);
        if (pluginKey) return pluginKey;

        // Then check main RunningHub key
        return PluginManager.getAiKey('runninghub');
    }

    /**
     * Check if RunningHub API key is configured in settings
     */
    function hasRunningHubApiKey() {
        return getRunningHubApiKey() !== '';
    }

    // Build fields - API key is shown only if not configured in settings
    const fields = [];

    // Only add API key field if not already configured
    if (!hasRunningHubApiKey()) {
        fields.push({
            id: 'apiKey',
            type: 'text',
            label: 'API Key',
            placeholder: 'Your RunningHub API key',
            description: 'Or configure in Settings → AI Keys'
        });
    }

    // Always add these fields
    fields.push(
        {
            id: 'model',
            type: 'select',
            label: 'Video Mode',
            default: 'landscape',
            options: [
                { value: 'portrait', label: 'Portrait (Vertical)' },
                { value: 'landscape', label: 'Landscape (Horizontal)' },
                { value: 'portrait-hd', label: 'HD Portrait' },
                { value: 'landscape-hd', label: 'HD Landscape' }
            ]
        },
        {
            id: 'prompt',
            type: 'textarea',
            label: 'Motion Prompt',
            placeholder: 'Describe the motion and scene...\n\nExample:\nCamera slowly zooms in, clouds moving gently across the sky, sunlight reflecting on water...',
            rows: 5
        },
        {
            id: 'duration_seconds',
            type: 'slider',
            label: 'Duration (seconds)',
            default: 10,
            min: 10,
            max: 15,
            step: 1
        }
    );

    // Register custom node: RunningHub AI App
    PluginManager.registerNode({
        type: 'runninghub-ai-app',
        category: 'generation',
        name: 'RunningHub AI App',
        description: 'Generate AI video from image',
        icon: 'clapperboard',
        inputs: [
            { id: 'image', type: 'image', label: 'Input Image' }
        ],
        outputs: [
            { id: 'video', type: 'video', label: 'Output Video' }
        ],
        fields: fields,
        preview: {
            type: 'video',
            source: 'output'
        },
        defaultData: {
            apiKey: '',
            model: 'landscape',
            prompt: '',
            duration_seconds: 10
        },
        // Custom execution handler (used by worker)
        execute: async function (node, inputs, context) {
            const { apiKey, model, prompt, duration_seconds } = node.data;
            const imageUrl = inputs.image || '';

            // Get API key - use node field or fall back to settings
            const finalApiKey = apiKey || getRunningHubApiKey();

            if (!finalApiKey) {
                throw new Error('RunningHub API Key is required. Set it in Settings → AI Keys or in the node field.');
            }

            if (!prompt) {
                throw new Error('Motion prompt is required');
            }

            // Build the API payload with hardcoded webapp ID
            const payload = {
                webappId: WEBAPP_ID,
                apiKey: finalApiKey,
                nodeInfoList: [
                    {
                        nodeId: '2',
                        fieldName: 'image',
                        fieldValue: imageUrl
                    },
                    {
                        nodeId: '1',
                        fieldName: 'model',
                        fieldValue: model
                    },
                    {
                        nodeId: '1',
                        fieldName: 'prompt',
                        fieldValue: prompt
                    },
                    {
                        nodeId: '1',
                        fieldName: 'duration_seconds',
                        fieldValue: String(duration_seconds)
                    }
                ]
            };

            // Return the payload for server-side execution
            return {
                action: 'runninghub-ai-app',
                payload: payload,
                endpoint: 'https://www.runninghub.ai/task/openapi/ai-app/run'
            };
        }
    });

    console.log('✅ RunningHub AI App plugin loaded' + (hasRunningHubApiKey() ? ' (API key configured)' : ''));

})();
